#!/bin/bash
sudo apt-get install freeglut3-dev glew-utils libglew-dev libfreeimage-dev	
