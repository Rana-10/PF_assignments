#ifndef TETRIS_CPP_
#define TETRIS_CPP_
#include "util.h"
#include <iostream>
#include<vector>
#include<algorithm>
#include <fstream>
//#include<cstdlib>
#include<ctime>
#include<string>
//#include<sys/wait.h>
//#include<stdlib.h>
//#include<stdio.h>
#include<unistd.h>
#include<sstream>
#include<cmath>   
using namespace std;

/* Function sets canvas size (drawing area) in pixels...
 *  that is what dimensions (x and y) your game will have
 *  Note that the bottom-left coordinate has value (0,0) and top-right coordinate has value (width-1,height-1)
 * */
void SetCanvasSize(int width, int height) {
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
    glMatrixMode( GL_MODELVIEW);
    glLoadIdentity();
}

double startx=320,starty=300;
int square_x = 320;
int square_y = 325;

const int max_snake_size = 100;
int snake[max_snake_size][2];
int snake_lengthh = 1;
int score = 0;
int high_score = 0;
int highest_score = 0;

int x_left = 0;
int x_right = 0;
int y_up = 0;
int y_down = 0;


// game over boolean variable declaration

bool game_over = false;

int movement_x;
int movement_y;

// for Food   

int food_x = -1;
int food_y = -1;

int food_x1 = -1;
int food_y1 = -1;

int food_x2 = -1;
int food_y2 = -1;

int food_x3 = -1;
int food_y3 = -1;

int food_x4 = -1;
int food_y4 = -1;

int power_food_x = -1;
int power_food_y = -1;


int time_count = 0;
int power_food_elapsed_time = 0;
const int power_food_spawn_intervall = 400;

void Display(){

        if(x_left == 1)
       movement_x-=10;

       if(x_right == 1)
       movement_x +=10;

       if(y_up == 1)
       movement_y+=10;

       if(y_down == 1)
       movement_y-=10;

    // set the background color using function glClearColotgr.
    // to change the background play with the red, green and blue values below.
    // Note that r, g and b values must be in the range [0,1] where 0 means dim rid and 1 means pure red and so on.

    glClearColor(0/*Red Component*/, 0.0/*Green Component*/,
            0.0/*Blue Component*/, 0 /*Alpha component*/);// Red==Green==Blue==1 --> White Colour
    glClear(GL_COLOR_BUFFER_BIT);   //Update the colors

    // food code

    srand(time(0));
    if(food_x != -1 && food_y != -1)
    {
    DrawSquare( food_x , food_y , 10 , colors[TOMATO]);
    DrawSquare( food_x1 , food_y1 , 10 , colors[TOMATO]);
    DrawSquare( food_x2 , food_y2 , 10 , colors[TOMATO]);
    DrawSquare( food_x3 , food_y3 , 10 , colors[TOMATO]);
    DrawSquare( food_x4 , food_y4 , 10 , colors[TOMATO]);
    DrawSquare( power_food_x , power_food_y , 10 , colors[KHAKI]);
    }  

    // for updating the scoreboard

    stringstream score_board;
    score_board << " Score = "<<score;
    string scoreStr = score_board.str();
    DrawString( 50, 600, scoreStr.c_str() , colors[ANTIQUE_WHITE]);

    // for updating the high score
    if(score > high_score)
    {
        high_score = score;
    }
    stringstream hs;
    hs << " High Score = "<<high_score;
    string highscoreStr = hs.str();
    
    ofstream output("high_score.txt");
    if(output.is_open())
    {
        output << high_score;
        output.close();
    }
    DrawString(450, 600, highscoreStr.c_str(), colors[ANTIQUE_WHITE]);
    

    // for Boundaries, used 4 loops.

    for(int i=160;i<=500;i++)
    {
          DrawSquare(i, 105, 10, colors[DARK_GRAY]);
    }

    for(int i=115;i<=485;i++)
    {
          DrawSquare(160, i, 10, colors[DARK_GRAY]);
    }

for(int i=160;i<=500;i++)
    {
          DrawSquare(i, 485, 10, colors[DARK_GRAY]);
    }

for(int i=115;i<=485;i++)
    {
          DrawSquare(500, i, 10, colors[DARK_GRAY]);
    }

    // hurdles

    // for x-axis  

    // for(int i = 205; i<=300; i++)
    // {
    //     DrawSquare(i, 145, 10, colors[DARK_GRAY]);
    // }

    // for y-axis

    // for(int i = 145; i<=275; i++)
    // {
    //     DrawSquare(200, i, 10, colors[DARK_GRAY]);
    // }


    // snake making and interaction with food.
    


    for(int i = 0; i< snake_lengthh; i++)
    {
        DrawSquare(snake[i][0], snake[i][1], 10, colors[GREEN]); // snake formation.

        int snake_position_x = snake[i][0];
        int snake_position_y = snake[i][1];

        if((food_x == snake[i][0]) && (food_y == snake[i][1]))
        {
            snake_lengthh += 1;
            food_x = 9000; // assigning values which are out of the frame, as after eating the food, it should disappear.
            food_y = 9990;
            score+=5;

        }

        if((food_x1 == snake[i][0]) && (food_y1 == snake[i][1]))
        {
            snake_lengthh += 1;
            food_x1 = -10;
            food_y1 = -15;
            score+=5;

        }

        if((food_x2 == snake[i][0]) && (food_y2 == snake[i][1]))
        {
            snake_lengthh += 1;
            food_x2 = -20;
            food_y2= -25;
            score+=5;

        }

        if((food_x3 == snake[i][0]) && (food_y3 == snake[i][1]))
        {
            snake_lengthh += 1;
            food_x3 = -30;
            food_y3 = -35;
            score+=5;

        }

        if((food_x4 == snake[i][0]) && (food_y4 == snake[i][1]))
        {
            snake_lengthh += 1;
            food_x4 = -40;
            food_y4 = -45;
            score+=5;

        }

        if((power_food_x == snake[i][0]) && (power_food_y == snake[i][1]))
        {
            snake_lengthh += 2;
            power_food_x = -60;
            power_food_y = -75;
            score+=20;

        }


        // we need the exception for head. Since in arrays, indexing starts from 0 hence 0 ko exception kar diya.
        // != condition ais lie, tah ke to avoid the head checking for collision with itself.
        if( (i!=0) && snake_position_x == snake[0][0] && snake_position_y == snake[0][1])
        {
            cout << " **** GAME OVER **** "<<endl;
            cout << " Your score is "<<score<<endl;
            cout << " High score is "<<high_score<<endl;
            game_over = true;
            exit(0);
        }
    }

    // assigning these two new variables, values.

    movement_x = snake[0][0];
    movement_y = snake[0][1]; 

    //  DrawTriangle( 300, 50 , 500, 50 , 400 , 250, colors[MISTY_ROSE] );  // Trianlge Vertices v1(300,50) , v2(500,50) , v3(400,250)
    
    //DrawLine(int x1, int y1, int x2, int y2, int lwidth, float *color)
    // DrawLine( 550 , 50 ,  550 , 600 , 20 , colors[MISTY_ROSE] );
     
   glutSwapBuffers(); // do not modify this line..
}



// This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
// program coordinates of mouse pointer when key was pressed.
 

void NonPrintableKeys(int key, int x, int y) {
    x_left = 0;
    x_right = 0;
    y_up = 0;
    y_down = 0;

    if (key == GLUT_KEY_LEFT)
    {	
        x_left = 1;   
    } 
    else if (key == GLUT_KEY_RIGHT) 
    {   
        x_right = 1;
    }
    else if (key == GLUT_KEY_UP)
    {
        y_up = 1;
    }
    else if (key == GLUT_KEY_DOWN)
    {
        y_down = 1;
    }

// moved all this data into a separate function and then calling that function into timer so that motion is continuous.

//     for (int i = snake_lengthh - 1; i > 0; i--)
// {
//     snake[i][0] = snake[i - 1][0];
//     snake[i][1] = snake[i - 1][1];
// }

//     if((movement_x > 160 && movement_x < 500 ) && (movement_y > 105 && movement_y < 485))
//     {
//        snake[0][0] = movement_x;
//        snake[0][1] = movement_y;

//     }

    // movement_x = snake[0][0];
    // movement_y = snake[0][1];


    /* This function calls the Display function to redo the drawing. Whenever you need to redraw just call
     * this function*/
     glutPostRedisplay();


}

/*This function is called (automatically) whenever any printable key (such as x,b, enter, etc.)
 * is pressed from the keyboard
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 * */
void PrintableKeys(unsigned char key, int x, int y) {
    if (key == KEY_ESC/* Escape key ASCII*/) {
        exit(1); // exit the program when escape key is pressed.
    }
    if (key == 'R' || key=='r'/* Escape key ASCII*/) {
        //exit(1); // exit the program when escape key is pressed.
    	//aswangle+=90;
    }
    
    else if (int(key) == 13)
    {  
	}
    
    glutPostRedisplay();

    
}

void hi_score()
{
    ifstream input("high_score.txt");
    if(input.is_open())
    {
    input >> high_score;
    input.close();
    }

}
// made this function so that the snake moves without stopping and we have to only control the direction.

void consecutive_snake_motion() {
    for (int i = snake_lengthh - 1; i > 0; i--) {
        snake[i][0] = snake[i - 1][0];
        snake[i][1] = snake[i - 1][1];
    }

    if ((x_left == 1) && (movement_x > 160)) {
        movement_x -= 10;
    } else if ((x_right == 1) && (movement_x < 500)) {
        movement_x += 10;
    } else if ((y_up == 1) && (movement_y < 485)) {
        movement_y += 10;
    } else if ((y_down == 1) && (movement_y > 105)) {
        movement_y -= 10;
    }

    snake[0][0] = movement_x;
    snake[0][1] = movement_y;
}


void Timer(int m) {
time_count++;
power_food_elapsed_time++; // logic to spawn power food lesser.
if(time_count >=150)
{
    // to generate a random food value between two limits, we use the formula - rand()%(max-min + 1) + min

    food_x = rand() % ((500 - 160) / 10) * 10 + 160; 
    food_y = rand() % ((485 - 105) / 10) * 10 + 105;

    food_x1 = rand() % ((500 - 160) / 10) * 10 + 160; 
    food_y1 = rand() % ((485 - 105) / 10) * 10 + 105;

    food_x2 = rand() % ((500 - 160) / 10) * 10 + 160; 
    food_y2 = rand() % ((485 - 105) / 10) * 10 + 105;

    food_x3 = rand() % ((500 - 160) / 10) * 10 + 160; 
    food_y3 = rand() % ((485 - 105) / 10) * 10 + 105;

    food_x4 = rand() % ((500 - 160) / 10) * 10 + 160; 
    food_y4 = rand() % ((485 - 105) / 10) * 10 + 105;

    // reset the elapsed time back to zero
    time_count = 0;

}
// using this formula so that power food spawns less.

    if(power_food_elapsed_time % power_food_spawn_intervall == 0)
    {
    power_food_x = rand() % ((500 - 160) / 10) * 10 + 160; 
    power_food_y = rand() % ((485 - 105) / 10) * 10 + 105; 
    }
    // calling it into timer function so that it is called repeatedly and thus movement is continuous.

    consecutive_snake_motion(); 

    // glutTimerFunc(100, Timer, 0);
	glutPostRedisplay();
    // once again we tell the library to call our Timer function after next 1000/FPS
    glutTimerFunc(350.0 / FPS, Timer, 0);
}



int main(int argc, char*argv[]) {

snake[0][0] = 320;
snake[0][1] = 325;

hi_score(); // function responsible for high score stuff.

    int width = 650, height = 650; 
    InitRandomizer(); // seed the random number generator...
    glutInit(&argc, argv); // initialize the graphics library...

    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
    glutInitWindowPosition(50, 50); // set the initial position of our window
    glutInitWindowSize(width, height); // set the size of our window
    glutCreateWindow("PF's Snake Game"); // set the title of our game window
    SetCanvasSize(width, height); // set the number of pixels...

// Register your functions to the library,
// you are telling the library names of function to call for different tasks.
//glutDisplayFunc(display); // tell library which function to call for drawing Canvas.
    glutDisplayFunc(Display); // tell library which function to call for drawing Canvas.
    glutSpecialFunc(NonPrintableKeys); // tell library which function to call for non-printable ASCII characters
    glutKeyboardFunc(PrintableKeys); // tell library which function to call for printable ASCII characters
// This function tells the library to call our Timer function after 1000.0/FPS milliseconds...
    glutTimerFunc(5.0 / FPS, Timer, 0);

// now handle the control to library and it will call our registered functions when
// it deems necessary...
    glutMainLoop();
    return 1;
}
#endif /* Snake Game */

